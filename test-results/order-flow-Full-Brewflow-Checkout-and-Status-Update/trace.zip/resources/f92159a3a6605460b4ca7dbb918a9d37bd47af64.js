(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_0m7ipaj._.js","static/chunks/app_0_zh5.y._.js","static/chunks/app_globals_0jn8.0u.css"],
    source: "dynamic"
});
